"""Infrastructure face recognition adapters"""
from infrastructure.face_recognition.insightface_adapter import InsightFaceAdapter

__all__ = ['InsightFaceAdapter']
