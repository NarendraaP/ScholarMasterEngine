This system runs on Edge Hardware (M2) to monitor Student Attendance, Emotion, and Safety using Vector Search.
