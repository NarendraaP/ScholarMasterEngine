"""API package for REST endpoints"""
from api.main import app

__all__ = ['app']
