"""Infrastructure indexing adapters"""
from infrastructure.indexing.faiss_face_index import FaissFaceIndex

__all__ = ['FaissFaceIndex']
